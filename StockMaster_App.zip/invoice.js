// invoice.js
document.addEventListener('DOMContentLoaded', () => {
    // Make function globally available so it can be called on tab switch or after transaction
    window.renderInvoicesTable = function() {
        let transactions = window.Store.getTransactions();
        const tbody = document.querySelector('#invoices-table tbody');
        
        if (!tbody) return; // Prevent error if not on right page (though it's single page)
        
        // Filter by Admin Panel Search if it exists
        const searchInput = document.getElementById('admin-invoice-search');
        if (searchInput && searchInput.value) {
            const query = searchInput.value.toLowerCase().trim();
            const persons = window.Store.getPersons();
            
            transactions = transactions.filter(tx => {
                const personObj = persons.find(p => p.name === tx.person);
                const personIndex = persons.findIndex(p => p.name === tx.person);
                const personSearchStr = personObj ? `${personIndex + 1} - ${personObj.name}`.toLowerCase() : (tx.person || '').toLowerCase();
                
                return personSearchStr.includes(query) || (tx.id && tx.id.toLowerCase().includes(query));
            });
        }

        tbody.innerHTML = '';

        if (transactions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No transactions found.</td></tr>';
            return;
        }

        transactions.forEach(tx => {
            let itemName = tx.itemName;
            if (!itemName) {
                const item = window.Store.getItems().find(i => i.id === tx.itemId);
                itemName = item ? item.name : 'Unknown Item';
            }
            const dateObj = new Date(tx.date);

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    ${tx.person || 'N/A'}
                    <br><small style="color: var(--text-secondary); font-size: 11px; font-weight: 400;">${tx.id}</small>
                </td>
                <td>${dateObj.toLocaleDateString()} ${dateObj.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</td>
                <td><span class="badge ${tx.type === 'in' ? 'badge-in' : 'badge-out'}">${tx.type.toUpperCase()}</span></td>
                <td>${itemName}</td>
                <td>${parseFloat(tx.totalAmount).toFixed(2)}</td>
                <td>${parseFloat(tx.remainingAmount).toFixed(2)}</td>
                <td>
                    <button class="action-btn" title="Print Invoice (English)" onclick="printInvoice('${tx.id}', 'en')">
                        <i class='bx bx-printer'></i>
                    </button>
                    <button class="action-btn" title="Print Invoice (Urdu)" onclick="printInvoice('${tx.id}', 'ur')">
                        <strong style="font-size: 14px;">UR</strong>
                    </button>
                    <button class="action-btn del" title="Delete Invoice" onclick="deleteInvoice('${tx.id}')">
                        <i class='bx bx-trash'></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    };

    // Initial render
    window.renderInvoicesTable();

    // Attach search event listener if on Admin Panel
    const searchInput = document.getElementById('admin-invoice-search');
    if (searchInput) {
        searchInput.addEventListener('input', window.renderInvoicesTable);
    }

    // Auto-print if triggered from another page
    const urlParams = new URLSearchParams(window.location.search);
    const printTxId = urlParams.get('print');
    if (printTxId) {
        // Clear the URL to prevent re-printing on manual refresh
        window.history.replaceState({}, document.title, window.location.pathname);
        const lang = localStorage.getItem('lang') || 'en';
        // Delay slightly to ensure page and translations are fully loaded
        setTimeout(() => {
            if (typeof printInvoice === 'function') {
                printInvoice(printTxId, lang);
            }
        }, 300);
    }
});

function printInvoice(txId, lang = 'en') {
    const transactions = window.Store.getTransactions();
    const tx = transactions.find(t => t.id === txId);
    
    if (!tx) {
        alert("Transaction not found.");
        return;
    }

    let itemName = tx.itemName;
    if (!itemName) {
        const item = window.Store.getItems().find(i => i.id === tx.itemId);
        itemName = item ? item.name : 'Unknown Item';
    }

    // Set Translations
    const t = {
        title: lang === 'ur' ? "بل / انوائس" : "INVOICE",
        company: lang === 'ur' ? "سٹاک ماسٹر" : "StockMaster Systems",
        date: lang === 'ur' ? "تاریخ: " : "Date: ",
        person: lang === 'ur' ? "نام: " : "Person: ",
        labelType: lang === 'ur' ? "قسم:" : "Transaction Type:",
        labelItem: lang === 'ur' ? "آئٹم:" : "Item:",
        thDesc: lang === 'ur' ? "تفصیل" : "Description",
        thWeight: lang === 'ur' ? "وزن" : "Weight",
        thRate: lang === 'ur' ? "ریٹ/کلو" : "Rate/Kg",
        thTotal: lang === 'ur' ? "کل رقم" : "Total",
        tdDesc: lang === 'ur' ? "سٹاک ریکارڈ" : "Stock Record",
        labelKg: lang === 'ur' ? "کلو" : "Kg",
        labelPaid: lang === 'ur' ? "ادا شدہ:" : "Paid:",
        labelRem: lang === 'ur' ? "بقایا:" : "Remaining:",
        footer: lang === 'ur' ? "ہمارے ساتھ کاروبار کرنے کا شکریہ!" : "Thank you for your business!",
        typeIn: lang === 'ur' ? "خریداری (Stock In)" : "Stock In (Purchase)",
        typeOut: lang === 'ur' ? "فروخت (Stock Out)" : "Stock Out (Sale)",
        mun: lang === 'ur' ? "من" : "Mun",
        kg: lang === 'ur' ? "کلو" : "Kg",
        gram: lang === 'ur' ? "گرام" : "g",
        ltr: lang === 'ur' ? "لیٹر" : "L",
        ml: lang === 'ur' ? "ملی لیٹر" : "ml"
    };

    // Populate Print Template
    document.getElementById('print-title').textContent = t.title;
    document.getElementById('print-company').textContent = t.company;
    
    document.getElementById('invoice-date').textContent = t.date + new Date(tx.date).toLocaleString();
    document.getElementById('invoice-person').textContent = t.person + (tx.person || 'N/A');
    document.getElementById('label-type').textContent = t.labelType;
    document.getElementById('invoice-type').textContent = tx.type.toUpperCase() === 'IN' ? t.typeIn : t.typeOut;
    
    document.getElementById('label-item').textContent = t.labelItem;
    document.getElementById('invoice-item').textContent = itemName;

    document.getElementById('th-desc').textContent = t.thDesc;
    document.getElementById('th-weight').textContent = t.thWeight;
    document.getElementById('th-rate').textContent = t.thRate;
    document.getElementById('th-total').textContent = t.thTotal;
    
    document.getElementById('td-desc').textContent = t.tdDesc;
    document.getElementById('label-kg').textContent = t.labelKg;
    
    document.getElementById('label-paid-print').textContent = t.labelPaid;
    document.getElementById('label-rem-print').textContent = t.labelRem;
    document.getElementById('print-footer').textContent = t.footer;

    // Apply RTL for Urdu
    const printArea = document.getElementById('print-area');
    if (lang === 'ur') {
        printArea.style.direction = 'rtl';
        printArea.style.fontFamily = '"Jameel Noori Nastaleeq", "Noto Nastaliq Urdu", Arial, sans-serif';
    } else {
        printArea.style.direction = 'ltr';
        printArea.style.fontFamily = 'inherit';
    }

    let weightStr = [];
    if (tx.weight.mun > 0) weightStr.push(`${tx.weight.mun} ${t.mun}`);
    if (tx.weight.kg > 0) weightStr.push(`${tx.weight.kg} ${t.kg}`);
    if (tx.weight.grams > 0) weightStr.push(`${tx.weight.grams} ${t.gram}`);
    if (tx.weight.ltr > 0) weightStr.push(`${tx.weight.ltr} ${t.ltr}`);
    if (tx.weight.ml > 0) weightStr.push(`${tx.weight.ml} ${t.ml}`);
    
    if(weightStr.length === 0) weightStr.push(`0 ${t.kg}`);

    document.getElementById('invoice-weight-text').textContent = weightStr.join(', ');
    document.getElementById('invoice-kg-total').textContent = parseFloat(tx.totalKg).toFixed(3);
    
    document.getElementById('invoice-rate').textContent = parseFloat(tx.ratePerKg).toFixed(2);
    document.getElementById('invoice-total').textContent = parseFloat(tx.totalAmount).toFixed(2);
    
    document.getElementById('invoice-paid').textContent = parseFloat(tx.paidAmount).toFixed(2);
    document.getElementById('invoice-remaining').textContent = parseFloat(tx.remainingAmount).toFixed(2);

    // Set document title to auto-populate PDF filename
    const originalTitle = document.title;
    document.title = `Invoice-${tx.id}`;

    // Trigger Print
    setTimeout(() => {
        window.print();
        document.title = originalTitle;
    }, 100);
}

function deleteInvoice(txId) {
    if (confirm("Are you sure you want to delete this invoice? This action cannot be undone.")) {
        window.Store.deleteTransaction(txId);
        window.renderInvoicesTable();
        if (typeof updateDashboard === 'function') {
            updateDashboard();
        }
    }
}
